// console.log("Background running");
// chrome.browserAction.onClicked.addListener(IconClicked);
// function IconClicked(tab)
// {
// 	// var amount = document.getElementById("sc-subtotal-amount-buybox").textContent;
// 	// var d = parseInt(amount);
// 	// console.log(d);
// 	let msg = {
// 		txt : "Hello"
// 	}
// 	chrome.tabs.sendMessage(tab.id,msg);
// }